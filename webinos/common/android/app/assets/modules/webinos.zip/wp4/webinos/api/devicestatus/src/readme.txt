aspects_win and device_example folders will be removed

put linux implementations in aspects/platform/linux
put windows implementations in aspects/platform/win
