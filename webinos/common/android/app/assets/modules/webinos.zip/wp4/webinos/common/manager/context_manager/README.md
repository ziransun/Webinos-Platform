Context manager requires following node_modules:
1. JSORM
2. sqlite3

(They are located in MAIN_REPOSITORY/node_modules/ and need to be compiled in order to use them.)


To use context manager set contextEnabled to true. By default this value is false. 
1.. Windows: APP_DATA/webinos/context_manager/settings.json
2. Linux/MAC: HOME_DIR/.webinos/context_manager/settings.json
3. Android: External_Storage/.webinos/context_manager/settings.json

